import java.util.Random;

public class Main {
    public static void main(String[] args) {
//Напишите программу, в которой объявите переменные всех примитивных типов.
// Значение для каждой переменной сгенерируйте с помощью класса Random.
// При необходимости используйте приведение типов. Полученные значения выведите в консоль.
//2 В этой же программе создайте переменную типа String.
// Сгенерируйте значение для строки. При необходимости используйте метод String.valueOf().
// Ограничений на длину строки и содержимое нет. Полученное значение выведите в консоль.
        Random rnd = new Random();

        byte byteVariable = (byte) rnd.nextInt();
        short shortVariable = (short) rnd.nextInt();
        int intVariable = rnd.nextInt();
        long longVariable = rnd.nextLong();
        float floatVariable = rnd.nextFloat();
        double doubleVariable = rnd.nextDouble();
        boolean booleanVariable = rnd.nextBoolean();
        char charVariable = (char) (rnd.nextInt(26) + 'a');

        System.out.println("byteVariable: " + byteVariable);
        System.out.println("shortVariable: " + shortVariable);
        System.out.println("intVariable: " + intVariable);
        System.out.println("longVariable: " + longVariable);
        System.out.println("floatVariable: " + floatVariable);
        System.out.println("doubleVariable: " + doubleVariable);
        System.out.println("booleanVariable: " + booleanVariable);
        System.out.println("charVariable: " + charVariable);

        String stringVariable = String.valueOf(rnd.nextInt());
        System.out.println("stringVariable: " + stringVariable);
    }
}