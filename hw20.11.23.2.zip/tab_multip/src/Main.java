import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Необходимо написать программу, которая проверяет пользователя на знание таблицы умножения.
        // Программа генерирует два целых однозначных числа. Программа задаёт вопрос:
        // результат умножения первого числа на второе?
        // Пользователь должен ввести ответ и увидеть на экране правильно он ответил или нет.
        // Если пользователь ответил неправильно, то программа должна показать правильный ответ.
        Random rnd = new Random();
        Scanner scr = new Scanner(System.in);

        int num1 = rnd.nextInt(9) + 1;
        int num2 = rnd.nextInt(9) + 1;

        System.out.println("Сколько будет " + num1 + " умножить на " + num2 + "? ");

        int user = scr.nextInt();
        int right = num1 * num2;
        if (user == right) {
            System.out.println("Верно!");
        } else {
            System.out.println("Неверно!");
            System.out.println("Правильный ответ: " + right);
        }
    }
}