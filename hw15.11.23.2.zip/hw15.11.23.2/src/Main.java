import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
// Пользователь-продавец вводит суммарную стоимость покупок и сумму денег,
// которую дал покупатель.
// Выведите сумму сдачи в виде “X рублей и Y копеек”.

        Scanner scr = new Scanner(System.in);

        System.out.println("Введите суммарную стоимость покупок:");
        double price = scr.nextDouble();

        System.out.println("Введите сумму денег, которую дал покупатель: ");
        double sumpay = scr.nextDouble();

        double change = sumpay - price;
        int rubles = (int) change;
        int kop = (int) ((change - rubles) * 100);

        System.out.println("Сдача: " + rubles + " рублей и " + kop + " копеек");
    }
}