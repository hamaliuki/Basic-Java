import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Напишите программу, которая получает от пользователя два целых числа
        // и затем вычисляет сумму (сложение), разницу (вычитание),
        // произведение (умножение) и частное
        // (деление) введённых чисел. Результат вычисления выведите в консоль.
        Scanner scr = new Scanner(System.in);

        System.out.println("Введите первое число:");
        int num1 = scr.nextInt();
        System.out.println("Введите второе число:");
        int num2 = scr.nextInt();

        int summa = num1 + num2;
        int differ = num1 - num2;
        int multip = num1 * num2;
        double division = num1 / num2;
        System.out.println("Сумма " + summa);
        System.out.println("Разница " + differ);
        System.out.println("Умножение " + multip);
        System.out.println("Деление " + division);
    }
}