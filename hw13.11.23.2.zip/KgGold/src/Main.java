import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//Напишите программу, которая принимает от пользователя его имя, возраст (полных лет) и вес.
// Когда все данные введены, программа должна выдать сообщение:
// «Уважаемый, [Имя]! В свои [Возраст] лет Вы для нас дороги, как [Вес] килограмм золота.».
// В сообщении [Имя], [Возраст] и [Вес] должны принять введённые значения.
        Scanner scr = new Scanner(System.in);

        System.out.println("Введите имя: ");
        String name = scr.nextLine();

        System.out.print("Введите возраст: ");
        int age = scr.nextInt();

        System.out.print("Введите вес: ");
        int weight = scr.nextInt();

        System.out.println("Уважаемый, " + name + "! В свои " + age +
                " лет Вы для нас дороги, как " + weight + " килограмм золота :)" );
    }
}