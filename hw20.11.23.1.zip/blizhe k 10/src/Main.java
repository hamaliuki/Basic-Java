import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //№1 Создать программу, выводящую на экран ближайшее к 10 из двух чисел, записанных в переменные m и n.
        //Числа могут быть, как целочисленные, так и дробные.
        //Например :
        //ввод : m=7, n=11
        //вывод: Число 11 ближе к 10.

        Scanner scr = new Scanner(System.in);

        System.out.println("Введите число m: ");
        double m = scr.nextDouble();

        System.out.println("Введите число n: ");
        double n = scr.nextDouble();

        double difm = Math.abs(10 - m);
        double difn = Math.abs(10 - n);
        if (difm < difn) {
            System.out.println("Ближайшее к 10 число: " + m);
        } else {
            System.out.println("Ближайшее к 10 число: " + n);
        }
    }
}