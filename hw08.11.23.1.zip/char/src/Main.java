public class Main {
    public static void main(String[] args) {
        char myChar = 'G';
        int myInt = 89;
        byte myByte = 4;
        short myShort = 56;
        float myFloat = 4.7333436f;
        double myDouble = 4.355453532;
        long myLong = 12121;

        System.out.println("char: " + myChar);
        System.out.println("int: " + myInt);
        System.out.println("byte: " + myByte);
        System.out.println("short: " + myShort);
        System.out.println("float: " + myFloat);
        System.out.println("double: " + myDouble);
        System.out.println("long: " + myLong);
    }
}